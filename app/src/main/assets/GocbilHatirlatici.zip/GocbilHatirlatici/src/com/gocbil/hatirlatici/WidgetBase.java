package com.gocbil.hatirlatici;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.TypedValue;
import android.widget.RemoteViews;

/**
 * 5 widget'in ortak tabani. Her widget sadece kind() ile turunu soyler.
 */
public abstract class WidgetBase extends AppWidgetProvider {

    public static final int K_DAYS = 0;     // 2x2 kalan gun
    public static final int K_STATUS = 1;   // 4x1 durum seridi
    public static final int K_PROGRESS = 2; // 4x2 donem ilerlemesi
    public static final int K_NEXT = 3;     // 4x1 siradaki hatirlatma
    public static final int K_QUICK = 4;    // 2x1 hizli dogrulama

    private static final Class[] PROVIDERS = {
            WidgetDays.class,
            WidgetStatus.class,
            WidgetProgress.class,
            WidgetNext.class,
            WidgetQuick.class
    };

    protected abstract int kind();

    @Override
    public void onUpdate(Context ctx, AppWidgetManager m, int[] ids) {
        for (int i = 0; i < ids.length; i++) {
            try {
                m.updateAppWidget(ids[i], build(ctx, kind()));
            } catch (Exception e) {
                // widget cizilemezse sessizce gec
            }
        }
    }

    @Override
    public void onEnabled(Context ctx) {
        Scheduler.scheduleRefresh(ctx);
    }

    /** Ekrandaki tum widget'lari gunceller. */
    public static void updateAll(Context ctx) {
        try {
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            for (int k = 0; k < PROVIDERS.length; k++) {
                int[] ids = m.getAppWidgetIds(new ComponentName(ctx, PROVIDERS[k]));
                if (ids == null) {
                    continue;
                }
                for (int i = 0; i < ids.length; i++) {
                    m.updateAppWidget(ids[i], build(ctx, k));
                }
            }
        } catch (Exception e) {
            // widget yoksa ya da cizilemezse sessizce gec
        }
    }

    private static PendingIntent openPi(Context ctx, int kind, boolean confirm) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (confirm) {
            i.putExtra(MainActivity.EXTRA_CONFIRM_DONE, true);
        }
        int code = 4000 + kind * 2 + (confirm ? 1 : 0);
        return PendingIntent.getActivity(ctx, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | Scheduler.immutableFlag());
    }

    private static void setBig(RemoteViews rv, Status s, int normalSp, int smallSp) {
        rv.setTextViewText(R.id.wBig, s.big);
        int size = (s.big.length() > 3) ? smallSp : normalSp;
        rv.setTextViewTextSize(R.id.wBig, TypedValue.COMPLEX_UNIT_SP, size);
    }

    private static RemoteViews build(Context base, int kind) {
        Context ctx = Lang.wrap(base);
        Status s = Status.compute(ctx);
        String pkg = ctx.getPackageName();
        RemoteViews rv;

        switch (kind) {
            case K_STATUS:
                rv = new RemoteViews(pkg, R.layout.widget_status);
                rv.setTextViewText(R.id.wChip, s.label);
                rv.setInt(R.id.wChip, "setBackgroundResource", s.chipRes);
                if (s.hasDate) {
                    rv.setTextViewText(R.id.wNext, Scheduler.format(s.next));
                } else {
                    rv.setTextViewText(R.id.wNext, s.small);
                }
                setBig(rv, s, 28, 15);
                rv.setTextColor(R.id.wBig, s.color);
                rv.setTextViewText(R.id.wSmall, s.hasDate ? s.small : "");
                break;

            case K_PROGRESS:
                rv = new RemoteViews(pkg, R.layout.widget_progress);
                rv.setTextViewText(R.id.wTitle, ctx.getString(R.string.w_period));
                rv.setTextViewText(R.id.wChip, s.label);
                rv.setInt(R.id.wChip, "setBackgroundResource", s.chipRes);
                setBig(rv, s, 38, 24);
                rv.setTextColor(R.id.wBig, s.color);
                rv.setTextViewText(R.id.wSmall, s.small);
                int pct = Math.round(s.fraction * 100f);
                rv.setProgressBar(R.id.wBar, 100, pct, false);
                rv.setTextViewText(R.id.wPct, ctx.getString(R.string.w_pct, Integer.valueOf(pct)));
                if (s.hasDate) {
                    rv.setTextViewText(R.id.wLast, ctx.getString(R.string.w_last_label,
                            Scheduler.format(s.last)));
                    rv.setTextViewText(R.id.wNext, ctx.getString(R.string.w_next_label,
                            Scheduler.format(s.next)));
                } else {
                    rv.setTextViewText(R.id.wLast, "");
                    rv.setTextViewText(R.id.wNext, "");
                }
                break;

            case K_NEXT:
                rv = new RemoteViews(pkg, R.layout.widget_next);
                rv.setTextViewText(R.id.wLabel, ctx.getString(R.string.w_next_reminder));
                String title = s.hasDate ? ctx.getString(R.string.w_none)
                        : ctx.getString(R.string.w_open_setup);
                String time = "";
                if (s.hasDate) {
                    String[] titles = ctx.getResources().getStringArray(R.array.step_titles);
                    long now = System.currentTimeMillis();
                    for (int i = 0; i < Scheduler.STEP_COUNT; i++) {
                        long t = Scheduler.stepTime(ctx, s.next, i);
                        if (t > now) {
                            title = titles[i];
                            time = Scheduler.formatShort(t);
                            break;
                        }
                    }
                }
                rv.setTextViewText(R.id.wSub, title);
                rv.setTextViewText(R.id.wNext, time);
                break;

            case K_QUICK:
                rv = new RemoteViews(pkg, R.layout.widget_quick);
                rv.setTextViewText(R.id.wBtn, ctx.getString(R.string.w_done));
                setBig(rv, s, 30, 16);
                rv.setTextColor(R.id.wBig, s.color);
                rv.setTextViewText(R.id.wSmall, s.hasDate ? s.small : "");
                rv.setOnClickPendingIntent(R.id.wBtn, openPi(ctx, kind, true));
                break;

            default:
                rv = new RemoteViews(pkg, R.layout.widget_days);
                rv.setTextViewText(R.id.wChip, s.label);
                rv.setInt(R.id.wChip, "setBackgroundResource", s.chipRes);
                setBig(rv, s, 42, 26);
                rv.setTextViewText(R.id.wSmall, s.small);
                if (s.hasDate) {
                    rv.setTextViewText(R.id.wNext, ctx.getString(R.string.w_next_label,
                            Scheduler.format(s.next)));
                } else {
                    rv.setTextViewText(R.id.wNext, "");
                }
                break;
        }

        rv.setOnClickPendingIntent(R.id.wRoot, openPi(ctx, kind, false));
        return rv;
    }
}
