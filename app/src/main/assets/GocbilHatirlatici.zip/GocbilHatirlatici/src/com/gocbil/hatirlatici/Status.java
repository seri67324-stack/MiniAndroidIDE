package com.gocbil.hatirlatici;

import android.content.Context;

/**
 * Ana ekran ve widget'larin ortak kullandigi durum hesabi.
 */
public class Status {

    public static final int GREEN = 0xFF2E7D32;
    public static final int ORANGE = 0xFFEF6C00;
    public static final int RED = 0xFFC62828;
    public static final int GRAY = 0xFF6B7A90;

    public boolean hasDate;
    public long last;
    public long next;
    public int diff;
    public int color;
    public int chipRes;
    public String label;
    public String note;
    public String big;
    public String small;
    public float fraction;

    public static Status compute(Context ctx) {
        Context c = Lang.wrap(ctx);
        Status s = new Status();
        s.last = Scheduler.getLast(c);

        if (s.last == 0L) {
            s.hasDate = false;
            s.color = GRAY;
            s.chipRes = R.drawable.chip_none;
            s.label = c.getString(R.string.w_no_date);
            s.note = c.getString(R.string.w_open_setup);
            s.big = "-";
            s.small = c.getString(R.string.w_open_setup);
            s.fraction = 0f;
            return s;
        }

        s.hasDate = true;
        s.next = Scheduler.getNext(c);
        s.diff = Scheduler.daysBetween(Scheduler.today(), s.next);
        int diff = s.diff;

        if (diff > 2) {
            s.color = GREEN;
            s.chipRes = R.drawable.chip_ok;
            s.label = c.getString(R.string.status_ok);
            s.note = c.getString(R.string.note_ok);
            s.big = String.valueOf(diff);
            s.small = c.getString(R.string.days_left);
        } else if (diff == 2 || diff == 1) {
            s.color = ORANGE;
            s.chipRes = R.drawable.chip_soon;
            s.label = c.getString(R.string.status_soon);
            s.note = c.getString(R.string.note_soon);
            s.big = String.valueOf(diff);
            s.small = c.getString(R.string.days_left);
        } else if (diff == 0) {
            s.color = ORANGE;
            s.chipRes = R.drawable.chip_soon;
            s.label = c.getString(R.string.status_day1);
            s.note = c.getString(R.string.note_day1);
            s.big = c.getString(R.string.ring_today);
            s.small = c.getString(R.string.ring_day1);
        } else if (diff == -1) {
            s.color = ORANGE;
            s.chipRes = R.drawable.chip_soon;
            s.label = c.getString(R.string.status_day2);
            s.note = c.getString(R.string.note_day2);
            s.big = c.getString(R.string.ring_lastday);
            s.small = c.getString(R.string.ring_day2);
        } else {
            s.color = RED;
            s.chipRes = R.drawable.chip_over;
            s.label = c.getString(R.string.status_over);
            s.note = c.getString(R.string.note_over);
            s.big = String.valueOf(-diff - 1);
            s.small = c.getString(R.string.days_overdue);
        }

        if (diff <= 0) {
            s.fraction = 1f;
        } else {
            s.fraction = (Scheduler.PERIOD_DAYS - diff) / (float) Scheduler.PERIOD_DAYS;
        }
        return s;
    }
}
