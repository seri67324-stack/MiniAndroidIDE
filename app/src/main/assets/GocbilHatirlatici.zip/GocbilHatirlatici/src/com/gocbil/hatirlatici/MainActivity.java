package com.gocbil.hatirlatici;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends Activity {

    public static final String EXTRA_CONFIRM_DONE = "confirm_done";

    private static final int FIX_NOTIF = 0;
    private static final int FIX_EXACT = 1;
    private static final int FIX_BATT = 2;
    private static final int REQ_START = 1;
    private static final int REQ_FIX = 2;

    private static final int GREEN = 0xFF2E7D32;
    private static final int RED = 0xFFC62828;
    private static final int ORANGE = 0xFFEF6C00;
    private static final int NAVY = 0xFF0D2B5E;
    private static final int INK = 0xFF14213D;
    private static final int GRAY = 0xFF6B7A90;

    private static final int GUIDE_STEPS = 5;

    private static boolean exactDialogShown = false;

    private int guideStep = 0;
    private boolean forceGuide = false;

    private LinearLayout groupMain;
    private LinearLayout groupSetup;
    private LinearLayout llTimeline;
    private LinearLayout llHealth;
    private LinearLayout llTimes;
    private LinearLayout llHistory;
    private LinearLayout groupGuide;
    private LinearLayout llDiag;
    private LinearLayout llLang;
    private LinearLayout llGuideLang;
    private TextView tvGuideStep;
    private TextView tvGuideTitle;
    private TextView tvGuideBody;
    private TextView tvGuideStatus;
    private TextView btnGuideSkip;
    private Button btnGuideAction;
    private Button btnGuideBack;
    private Button btnGuideNext;
    private Button btnGocbil;
    private Button btnGuide;
    private RingView ring;
    private TextView tvStatusLabel;
    private TextView tvStatusNote;
    private TextView tvLast;
    private TextView tvNext;
    private TextView tvWindow;
    private TextView tvHealthBadge;
    private TextView tvHistorySummary;
    private DatePicker datePicker;
    private Button btnDone;
    private Button btnChange;
    private Button btnTest;
    private Button btnUndo;
    private Button btnToday;
    private Button btnSave;
    private Button btnCancel;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= 17) {
            getWindow().getDecorView().setLayoutDirection(Lang.isRtl(this)
                    ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        }

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(NAVY);
        }

        groupMain = (LinearLayout) findViewById(R.id.groupMain);
        groupSetup = (LinearLayout) findViewById(R.id.groupSetup);
        llTimeline = (LinearLayout) findViewById(R.id.llTimeline);
        llHealth = (LinearLayout) findViewById(R.id.llHealth);
        llTimes = (LinearLayout) findViewById(R.id.llTimes);
        llHistory = (LinearLayout) findViewById(R.id.llHistory);
        ring = (RingView) findViewById(R.id.ring);
        tvStatusLabel = (TextView) findViewById(R.id.tvStatusLabel);
        tvStatusNote = (TextView) findViewById(R.id.tvStatusNote);
        tvLast = (TextView) findViewById(R.id.tvLast);
        tvNext = (TextView) findViewById(R.id.tvNext);
        tvWindow = (TextView) findViewById(R.id.tvWindow);
        tvHealthBadge = (TextView) findViewById(R.id.tvHealthBadge);
        tvHistorySummary = (TextView) findViewById(R.id.tvHistorySummary);
        datePicker = (DatePicker) findViewById(R.id.datePicker);
        btnDone = (Button) findViewById(R.id.btnDone);
        btnChange = (Button) findViewById(R.id.btnChange);
        btnTest = (Button) findViewById(R.id.btnTest);
        btnUndo = (Button) findViewById(R.id.btnUndo);
        btnToday = (Button) findViewById(R.id.btnToday);
        btnSave = (Button) findViewById(R.id.btnSave);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        groupGuide = (LinearLayout) findViewById(R.id.groupGuide);
        llDiag = (LinearLayout) findViewById(R.id.llDiag);
        llLang = (LinearLayout) findViewById(R.id.llLang);
        llGuideLang = (LinearLayout) findViewById(R.id.llGuideLang);
        tvGuideStep = (TextView) findViewById(R.id.tvGuideStep);
        tvGuideTitle = (TextView) findViewById(R.id.tvGuideTitle);
        tvGuideBody = (TextView) findViewById(R.id.tvGuideBody);
        tvGuideStatus = (TextView) findViewById(R.id.tvGuideStatus);
        btnGuideSkip = (TextView) findViewById(R.id.btnGuideSkip);
        btnGuideAction = (Button) findViewById(R.id.btnGuideAction);
        btnGuideBack = (Button) findViewById(R.id.btnGuideBack);
        btnGuideNext = (Button) findViewById(R.id.btnGuideNext);
        btnGocbil = (Button) findViewById(R.id.btnGocbil);
        btnGuide = (Button) findViewById(R.id.btnGuide);

        btnGocbil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGocbil();
            }
        });

        btnGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guideStep = 0;
                forceGuide = true;
                refresh();
            }
        });

        btnGuideSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishGuide();
            }
        });

        btnGuideBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (guideStep > 0) {
                    guideStep--;
                    refresh();
                }
            }
        });

        btnGuideNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (guideStep < GUIDE_STEPS - 1) {
                    guideStep++;
                    refresh();
                } else {
                    finishGuide();
                }
            }
        });

        btnGuideAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (guideStep == 1) {
                    doFix(FIX_NOTIF);
                } else if (guideStep == 2) {
                    doFix(FIX_EXACT);
                } else if (guideStep == 3) {
                    doFix(FIX_BATT);
                }
            }
        });

        btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDone();
            }
        });

        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSetup(true);
            }
        });

        btnTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scheduler.startAlert(MainActivity.this, 2, true);
                Toast.makeText(MainActivity.this, R.string.test_sent, Toast.LENGTH_SHORT).show();
            }
        });

        btnUndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmUndo();
            }
        });

        btnToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDate(Scheduler.today());
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDate(getPickedDate());
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh();
            }
        });

        Scheduler.ensureChannel(this);
        if (Scheduler.guideDone(this)) {
            requestNotificationPermission();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Uygulama acilinca calan alarm sesi susar (bildirim kalir)
        AlarmService.stop(this, false);
        if (Scheduler.getLast(this) != 0L) {
            // Alarmlarin yerinde oldugundan emin ol (izin degismis olabilir)
            Scheduler.scheduleAll(this);
        }
        refresh();
        maybeAskExactAlarm();
        handleIntent();
    }

    /** Widget'taki "Yaptim" dugmesi onay penceresini acar. */
    private void handleIntent() {
        Intent in = getIntent();
        if (in != null && in.getBooleanExtra(EXTRA_CONFIRM_DONE, false)) {
            in.removeExtra(EXTRA_CONFIRM_DONE);
            if (Scheduler.getLast(this) != 0L) {
                confirmDone();
            }
        }
    }

    // ---------- Izinler ----------

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},
                        REQ_START);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_FIX && !granted) {
            // Kalici reddedilmisse sistem pencere gostermez: ayar ekranina git
            openNotificationSettings();
        }
        refresh();
    }

    private void maybeAskExactAlarm() {
        if (exactDialogShown) {
            return;
        }
        if (groupGuide.getVisibility() == View.VISIBLE) {
            return;
        }
        if (Scheduler.getLast(this) == 0L) {
            return;
        }
        if (Scheduler.canScheduleExact(this)) {
            return;
        }
        exactDialogShown = true;
        new AlertDialog.Builder(this)
                .setTitle(R.string.exact_title)
                .setMessage(R.string.exact_msg)
                .setPositiveButton(R.string.open_settings, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        openExactAlarmSettings();
                    }
                })
                .setNegativeButton(R.string.later, null)
                .show();
    }

    private void openExactAlarmSettings() {
        try {
            Intent i = new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM");
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void openBatterySettings() {
        try {
            startActivity(new Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"));
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void openNotificationSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                Intent i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                i.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
                startActivity(i);
            } else {
                openAppDetails();
            }
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void openAppDetails() {
        try {
            Intent i = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, R.string.settings_error, Toast.LENGTH_LONG).show();
        }
    }

    private void doFix(int fix) {
        if (fix == FIX_NOTIF) {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},
                        REQ_FIX);
            } else {
                openNotificationSettings();
            }
        } else if (fix == FIX_EXACT) {
            openExactAlarmSettings();
        } else {
            openBatterySettings();
        }
    }

    // ---------- Ekran durumu ----------

    private void showSetup(boolean allowCancel) {
        groupMain.setVisibility(View.GONE);
        groupGuide.setVisibility(View.GONE);
        groupSetup.setVisibility(View.VISIBLE);
        if (allowCancel) {
            btnCancel.setVisibility(View.VISIBLE);
        } else {
            btnCancel.setVisibility(View.GONE);
        }
        long init = Scheduler.getLast(this);
        if (init == 0L) {
            init = Scheduler.today();
        }
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(init);
        datePicker.setMaxDate(System.currentTimeMillis());
        datePicker.updateDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH));
    }

    private void refresh() {
        if (forceGuide || !Scheduler.guideDone(this)) {
            showGuide();
            return;
        }
        groupGuide.setVisibility(View.GONE);
        long last = Scheduler.getLast(this);
        if (last == 0L) {
            showSetup(false);
            return;
        }
        groupSetup.setVisibility(View.GONE);
        groupMain.setVisibility(View.VISIBLE);

        Status st = Status.compute(this);

        tvLast.setText(Scheduler.format(st.last));
        tvNext.setText(Scheduler.format(st.next));
        tvWindow.setText(Scheduler.format(st.next) + "  -  "
                + Scheduler.format(Scheduler.addDays(st.next, 1)));

        GradientDrawable chip = new GradientDrawable();
        chip.setColor((st.color & 0x00FFFFFF) | 0x26000000);
        chip.setCornerRadius(dp(20));
        tvStatusLabel.setBackground(chip);
        tvStatusLabel.setTextColor(st.color);
        tvStatusLabel.setText(st.label);

        ring.setData(st.fraction, st.color, st.big, st.small);
        tvStatusNote.setText(st.note);

        buildTimeline(st.next);
        buildHealth();
        buildDiag();
        buildTimes();
        buildHistory();
        fillLang(llLang);

        if (Scheduler.canUndo(this)) {
            btnUndo.setVisibility(View.VISIBLE);
        } else {
            btnUndo.setVisibility(View.GONE);
        }
    }

    private void buildTimeline(long next) {
        llTimeline.removeAllViews();
        String[] titles = getResources().getStringArray(R.array.step_titles);
        long now = System.currentTimeMillis();

        int nextIdx = -1;
        for (int s = 0; s < Scheduler.STEP_COUNT; s++) {
            if (Scheduler.stepTime(this, next, s) > now) {
                nextIdx = s;
                break;
            }
        }

        for (int s = 0; s < Scheduler.STEP_COUNT; s++) {
            long t = Scheduler.stepTime(this, next, s);
            boolean past = t <= now;
            boolean isNext = (s == nextIdx);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(9), 0, dp(9));

            View dot = new View(this);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(14), dp(14));
            dlp.setMarginEnd(dp(14));
            dot.setLayoutParams(dlp);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            if (past) {
                g.setColor(GREEN);
            } else if (isNext) {
                g.setColor(0xFFFFFFFF);
                g.setStroke(dp(3), NAVY);
            } else {
                g.setColor(0xFFCBD5E3);
            }
            dot.setBackground(g);

            TextView title = new TextView(this);
            title.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            title.setText(titles[s]);
            title.setTextSize(15);
            if (past) {
                title.setTextColor(0xFF8896AB);
            } else if (isNext) {
                title.setTextColor(NAVY);
                title.setTypeface(Typeface.DEFAULT_BOLD);
            } else {
                title.setTextColor(INK);
            }

            TextView time = new TextView(this);
            time.setText(Scheduler.formatShort(t));
            time.setTextSize(14);
            time.setTextColor(isNext ? NAVY : GRAY);
            if (isNext) {
                time.setTypeface(Typeface.DEFAULT_BOLD);
            }

            row.addView(dot);
            row.addView(title);
            row.addView(time);
            llTimeline.addView(row);
        }
    }

    // ---------- Sistem kontrolu karti ----------

    private void buildHealth() {
        llHealth.removeAllViews();
        boolean n = Scheduler.notificationsEnabled(this);
        boolean e = Scheduler.canScheduleExact(this);
        boolean b = Scheduler.batteryUnrestricted(this);

        int bad = 0;
        if (!n) {
            bad++;
        }
        if (!e) {
            bad++;
        }
        if (!b) {
            bad++;
        }

        addHealthRow(R.string.h_notif, n ? R.string.h_notif_ok : R.string.h_notif_bad,
                n, FIX_NOTIF);
        addHealthRow(R.string.h_exact, e ? R.string.h_exact_ok : R.string.h_exact_bad,
                e, FIX_EXACT);
        addHealthRow(R.string.h_batt, b ? R.string.h_batt_ok : R.string.h_batt_bad,
                b, FIX_BATT);

        int color;
        String text;
        if (bad == 0) {
            color = GREEN;
            text = getString(R.string.health_ok);
        } else {
            color = (!n) ? RED : ORANGE;
            text = getString(R.string.health_issues, Integer.valueOf(bad));
        }
        GradientDrawable bg = new GradientDrawable();
        bg.setColor((color & 0x00FFFFFF) | 0x26000000);
        bg.setCornerRadius(dp(16));
        tvHealthBadge.setBackground(bg);
        tvHealthBadge.setTextColor(color);
        tvHealthBadge.setText(text);
    }

    private void addHealthRow(int titleRes, int statusRes, boolean ok, final int fix) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        int color = ok ? GREEN : RED;

        View dot = new View(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(12), dp(12));
        dlp.setMarginEnd(dp(14));
        dot.setLayoutParams(dlp);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        dot.setBackground(g);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText(titleRes);
        title.setTextSize(15);
        title.setTextColor(INK);
        title.setTypeface(Typeface.DEFAULT_BOLD);

        TextView status = new TextView(this);
        status.setText(statusRes);
        status.setTextSize(13);
        status.setTextColor(color);

        col.addView(title);
        col.addView(status);

        row.addView(dot);
        row.addView(col);

        if (!ok) {
            TextView fixBtn = pill(getString(R.string.health_fix));
            fixBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    doFix(fix);
                }
            });
            row.addView(fixBtn);
        }
        llHealth.addView(row);
    }

    private TextView pill(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13);
        t.setTextColor(NAVY);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundResource(R.drawable.btn_small);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setClickable(true);
        return t;
    }

    // ---------- Alarm tani karti ----------

    private void buildDiag() {
        llDiag.removeAllViews();
        int idx = Scheduler.nextStepIndex(this);
        if (idx < 0) {
            addInfoRow(llDiag, R.string.diag_next, getString(R.string.diag_next_none),
                    GRAY, null, null);
        } else {
            long t = Scheduler.stepTime(this, Scheduler.getNext(this), idx);
            if (Scheduler.alarmPending(this, idx)) {
                addInfoRow(llDiag, R.string.diag_next,
                        getString(R.string.diag_next_ok, Scheduler.formatShort(t)),
                        GREEN, null, null);
            } else {
                addInfoRow(llDiag, R.string.diag_next,
                        getString(R.string.diag_next_bad, Scheduler.formatShort(t)),
                        RED, getString(R.string.diag_reschedule),
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Scheduler.scheduleAll(MainActivity.this);
                                Toast.makeText(MainActivity.this, R.string.diag_rescheduled,
                                        Toast.LENGTH_SHORT).show();
                                refresh();
                            }
                        });
            }
        }

        long fired = Scheduler.getLastFired(this);
        if (fired == 0L) {
            addInfoRow(llDiag, R.string.diag_fired, getString(R.string.diag_fired_none),
                    GRAY, null, null);
        } else {
            String[] titles = getResources().getStringArray(R.array.step_titles);
            int fs = Scheduler.getLastFiredStep(this);
            String text = Scheduler.formatShort(fired);
            if (fs >= 0 && fs < titles.length) {
                text = text + "  -  " + titles[fs];
            }
            addInfoRow(llDiag, R.string.diag_fired, text, NAVY, null, null);
        }

        long rearm = Scheduler.getLastRearm(this);
        if (rearm == 0L) {
            addInfoRow(llDiag, R.string.diag_rearm, getString(R.string.diag_rearm_none),
                    GRAY, null, null);
        } else {
            addInfoRow(llDiag, R.string.diag_rearm, Scheduler.formatShort(rearm),
                    NAVY, null, null);
        }
    }

    private void addInfoRow(LinearLayout parent, int titleRes, String statusText, int color,
                            String pillText, View.OnClickListener pillListener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));

        View dot = new View(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(12), dp(12));
        dlp.setMarginEnd(dp(14));
        dot.setLayoutParams(dlp);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        dot.setBackground(g);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText(titleRes);
        title.setTextSize(15);
        title.setTextColor(INK);
        title.setTypeface(Typeface.DEFAULT_BOLD);

        TextView status = new TextView(this);
        status.setText(statusText);
        status.setTextSize(13);
        status.setTextColor(color);

        col.addView(title);
        col.addView(status);
        row.addView(dot);
        row.addView(col);

        if (pillText != null && pillListener != null) {
            TextView b = pill(pillText);
            b.setOnClickListener(pillListener);
            row.addView(b);
        }
        parent.addView(row);
    }

    // ---------- Dil ----------

    private void fillLang(LinearLayout row) {
        row.removeAllViews();
        String cur = Lang.get(this);
        addLangButton(row, getString(R.string.lang_tr), Lang.TR, Lang.TR.equals(cur), true);
        addLangButton(row, getString(R.string.lang_ar), Lang.AR, Lang.AR.equals(cur), false);
    }

    private void addLangButton(LinearLayout row, String text, final String code,
                               boolean selected, boolean first) {
        TextView t = new TextView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, dp(48), 1f);
        if (first) {
            lp.setMarginEnd(dp(6));
        } else {
            lp.setMarginStart(dp(6));
        }
        t.setLayoutParams(lp);
        t.setText(text);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        if (selected) {
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(NAVY);
            bg.setCornerRadius(dp(14));
            t.setBackground(bg);
            t.setTextColor(0xFFFFFFFF);
        } else {
            t.setBackgroundResource(R.drawable.btn_small);
            t.setTextColor(NAVY);
        }
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!code.equals(Lang.get(MainActivity.this))) {
                    Lang.set(MainActivity.this, code);
                    WidgetBase.updateAll(MainActivity.this);
                    recreate();
                }
            }
        });
        row.addView(t);
    }

    // ---------- Gocbil'i ac ----------

    private void openGocbil() {
        boolean found = Scheduler.gocbilInstalled(this);
        try {
            startActivity(Scheduler.gocbilIntent(this));
            if (!found) {
                Toast.makeText(this, R.string.gocbil_not_found, Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, R.string.gocbil_open_error, Toast.LENGTH_LONG).show();
        }
    }

    // ---------- Ilk acilis rehberi ----------

    private void showGuide() {
        groupMain.setVisibility(View.GONE);
        groupSetup.setVisibility(View.GONE);
        groupGuide.setVisibility(View.VISIBLE);

        String[] titles = getResources().getStringArray(R.array.guide_titles);
        String[] bodies = getResources().getStringArray(R.array.guide_bodies);
        tvGuideStep.setText(getString(R.string.guide_step_fmt,
                Integer.valueOf(guideStep + 1), Integer.valueOf(GUIDE_STEPS)));
        tvGuideTitle.setText(titles[guideStep]);
        tvGuideBody.setText(bodies[guideStep]);

        if (guideStep == 0) {
            llGuideLang.setVisibility(View.VISIBLE);
            fillLang(llGuideLang);
        } else {
            llGuideLang.setVisibility(View.GONE);
        }

        boolean permStep = guideStep >= 1 && guideStep <= 3;
        if (permStep) {
            boolean ok;
            boolean na = false;
            if (guideStep == 1) {
                ok = Scheduler.notificationsEnabled(this);
            } else if (guideStep == 2) {
                ok = Scheduler.canScheduleExact(this);
                na = (Build.VERSION.SDK_INT < 31);
            } else {
                ok = Scheduler.batteryUnrestricted(this);
            }
            tvGuideStatus.setVisibility(View.VISIBLE);
            if (ok) {
                tvGuideStatus.setTextColor(GREEN);
                tvGuideStatus.setText(na ? R.string.g_status_na : R.string.g_status_ok);
                btnGuideAction.setVisibility(View.GONE);
            } else {
                tvGuideStatus.setTextColor(RED);
                tvGuideStatus.setText(R.string.g_status_bad);
                btnGuideAction.setVisibility(View.VISIBLE);
                String[] acts = getResources().getStringArray(R.array.guide_actions);
                btnGuideAction.setText(acts[guideStep - 1]);
            }
        } else {
            tvGuideStatus.setVisibility(View.GONE);
            btnGuideAction.setVisibility(View.GONE);
        }

        btnGuideBack.setVisibility(guideStep > 0 ? View.VISIBLE : View.GONE);
        btnGuideNext.setText(guideStep == GUIDE_STEPS - 1
                ? R.string.guide_start : R.string.guide_next);
        btnGuideSkip.setVisibility(guideStep == GUIDE_STEPS - 1 ? View.INVISIBLE : View.VISIBLE);
    }

    private void finishGuide() {
        Scheduler.setGuideDone(this, true);
        forceGuide = false;
        guideStep = 0;
        requestNotificationPermission();
        refresh();
    }

    // ---------- Ayarlanabilir saatler ----------

    private void buildTimes() {
        llTimes.removeAllViews();
        String[] labels = getResources().getStringArray(R.array.time_labels);
        for (int g = 0; g < labels.length; g++) {
            final int group = g;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(6), 0, dp(6));

            TextView label = new TextView(this);
            label.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            label.setText(labels[g]);
            label.setTextSize(14);
            label.setTextColor(INK);
            label.setPaddingRelative(0, 0, dp(10), 0);

            TextView time = pill(Scheduler.formatTime(Scheduler.getTimeMin(this, g)));
            time.setTextSize(15);
            time.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pickTime(group);
                }
            });

            row.addView(label);
            row.addView(time);
            llTimes.addView(row);
        }
    }

    private void pickTime(final int group) {
        int cur = Scheduler.getTimeMin(this, group);
        new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                applyTime(group, hourOfDay * 60 + minute);
            }
        }, cur / 60, cur % 60, true).show();
    }

    private void applyTime(int group, int minutes) {
        int[] v = new int[4];
        for (int i = 0; i < 4; i++) {
            v[i] = Scheduler.getTimeMin(this, i);
        }
        v[group] = minutes;
        if (!Scheduler.timesValid(v[1], v[2], v[3])) {
            Toast.makeText(this, R.string.times_order_error, Toast.LENGTH_LONG).show();
            return;
        }
        Scheduler.setTimeMin(this, group, minutes);
        Scheduler.scheduleAll(this);
        refresh();
        Toast.makeText(this, R.string.times_saved, Toast.LENGTH_SHORT).show();
    }

    // ---------- Gecmis ----------

    private void buildHistory() {
        llHistory.removeAllViews();
        ArrayList<Long> h = Scheduler.getHistory(this);
        int n = h.size();

        if (n >= 2) {
            int total = Scheduler.daysBetween(h.get(0).longValue(), h.get(n - 1).longValue());
            int avg = Math.round(total / (float) (n - 1));
            tvHistorySummary.setText(getString(R.string.hist_avg, Integer.valueOf(avg)));
            tvHistorySummary.setVisibility(View.VISIBLE);
        } else {
            tvHistorySummary.setVisibility(View.GONE);
        }

        int shown = Math.min(n, 6);
        for (int k = 0; k < shown; k++) {
            int idx = n - 1 - k;
            final long t = h.get(idx).longValue();

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, dp(9), 0, dp(9));
            row.setClickable(true);

            TextView date = new TextView(this);
            date.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            date.setText(Scheduler.format(t));
            date.setTextSize(16);
            if (k == 0) {
                date.setTextColor(NAVY);
                date.setTypeface(Typeface.DEFAULT_BOLD);
            } else {
                date.setTextColor(INK);
            }

            TextView gap = new TextView(this);
            gap.setTextSize(13);
            gap.setTextColor(GRAY);
            if (idx > 0) {
                int days = Scheduler.daysBetween(h.get(idx - 1).longValue(), t);
                gap.setText(getString(R.string.hist_gap, Integer.valueOf(days)));
            } else {
                gap.setText(R.string.hist_first);
            }

            row.addView(date);
            row.addView(gap);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmDeleteHistory(t);
                }
            });
            llHistory.addView(row);
        }
    }

    private void confirmDeleteHistory(final long t) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.hist_del_title)
                .setMessage(getString(R.string.hist_del_msg, Scheduler.format(t)))
                .setPositiveButton(R.string.hist_delete, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (!Scheduler.deleteHistory(MainActivity.this, t)) {
                            Toast.makeText(MainActivity.this, R.string.hist_keep_one,
                                    Toast.LENGTH_LONG).show();
                        }
                        refresh();
                    }
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    // ---------- Islemler ----------

    private long getPickedDate() {
        Calendar c = Calendar.getInstance();
        c.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth(), 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private void saveDate(long picked) {
        if (picked > Scheduler.today()) {
            Toast.makeText(this, R.string.future_date, Toast.LENGTH_LONG).show();
            return;
        }
        Scheduler.cancelNotifications(this);
        Scheduler.recordDate(this, picked);
        Scheduler.scheduleAll(this);
        refresh();
        String msg = getString(R.string.saved_msg, Scheduler.format(Scheduler.getNext(this)));
        new AlertDialog.Builder(this)
                .setTitle(R.string.saved_title)
                .setMessage(msg)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        maybeAskExactAlarm();
                    }
                })
                .show();
    }

    private void confirmDone() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirm_done_title)
                .setMessage(R.string.confirm_done_msg)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        doDone();
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void doDone() {
        long next = Scheduler.markDone(this);
        refresh();
        String msg = getString(R.string.great_msg, Scheduler.format(next));
        new AlertDialog.Builder(this)
                .setTitle(R.string.app_name)
                .setMessage(msg)
                .setPositiveButton(R.string.ok, null)
                .show();
    }

    private void confirmUndo() {
        if (!Scheduler.canUndo(this)) {
            Toast.makeText(this, R.string.undo_none, Toast.LENGTH_SHORT).show();
            refresh();
            return;
        }
        String msg = getString(R.string.undo_msg, Scheduler.format(Scheduler.getUndoDate(this)));
        new AlertDialog.Builder(this)
                .setTitle(R.string.undo_title)
                .setMessage(msg)
                .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        doUndo();
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }

    private void doUndo() {
        if (Scheduler.undo(this)) {
            refresh();
            Toast.makeText(this, getString(R.string.undo_done,
                    Scheduler.format(Scheduler.getLast(this))), Toast.LENGTH_LONG).show();
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
