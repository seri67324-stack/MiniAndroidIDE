package com.gocbil.hatirlatici;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/**
 * Hatirlatma bildirimini on planda gosterir ve sesi ALARM kanalindan calar.
 * Alarm kanali telefon sessiz/titresim modundayken de duyulur
 * (Rahatsiz Etmeyin modu alarmlari engellemiyorsa).
 */
public class AlarmService extends Service {

    public static final String ACTION_STOP = "com.gocbil.hatirlatici.STOP_ALARM";
    public static final String EXTRA_REMOVE = "remove";

    private static volatile boolean running = false;

    private MediaPlayer player;
    private Vibrator vibrator;
    private AudioManager audio;
    private int oldVolume = -1;
    private Handler handler;
    private Runnable stopRunnable;

    /** Calisan alarmi durdurur. removeNotification=true ise bildirimi de kaldirir. */
    public static void stop(Context ctx, boolean removeNotification) {
        if (!running) {
            return;
        }
        try {
            Intent i = new Intent(ctx, AlarmService.class);
            i.setAction(ACTION_STOP);
            i.putExtra(EXTRA_REMOVE, removeNotification);
            ctx.startService(i);
        } catch (Exception e) {
            try {
                ctx.stopService(new Intent(ctx, AlarmService.class));
            } catch (Exception e2) {
                // yapilacak bir sey yok
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        stopRunnable = new Runnable() {
            @Override
            public void run() {
                shutdown(false);
            }
        };
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown(intent.getBooleanExtra(EXTRA_REMOVE, false));
            return START_NOT_STICKY;
        }

        int step = 2;
        boolean test = false;
        if (intent != null) {
            step = intent.getIntExtra(Scheduler.EXTRA_STEP, 2);
            test = intent.getBooleanExtra(Scheduler.EXTRA_TEST, false);
        }
        if (step < 0 || step >= Scheduler.STEP_COUNT) {
            step = 2;
        }

        try {
            Notification n = Scheduler.buildNotification(this, step, test);
            startForeground(Scheduler.FG_ID, n);
        } catch (Exception e) {
            Scheduler.showNotification(this, step, test);
            Scheduler.playFallbackSound(this);
            stopSelf();
            return START_NOT_STICKY;
        }

        running = true;
        startAlert(step, test);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(stopRunnable);
        stopSound();
        restoreVolume();
        running = false;
        super.onDestroy();
    }

    // ---------- Ses ----------

    private AudioAttributes alarmAttrs() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
    }

    private void startAlert(int step, boolean test) {
        stopSound();
        raiseVolume();

        AudioAttributes aa = alarmAttrs();
        boolean ok = tryPlay(Scheduler.soundUri(), aa);
        if (!ok) {
            ok = tryPlay(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa);
        }
        if (!ok) {
            tryPlay(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE), aa);
        }
        startVibration(aa);

        int duration = test ? 12000 : Scheduler.alertDuration(step);
        handler.removeCallbacks(stopRunnable);
        handler.postDelayed(stopRunnable, duration);
    }

    private boolean tryPlay(Uri uri, AudioAttributes aa) {
        if (uri == null) {
            return false;
        }
        MediaPlayer mp = new MediaPlayer();
        try {
            mp.setAudioAttributes(aa);
            mp.setDataSource(this, uri);
            mp.setLooping(true);
            mp.setVolume(1.0f, 1.0f);
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.prepare();
            mp.start();
            player = mp;
            return true;
        } catch (Exception e) {
            try {
                mp.release();
            } catch (Exception e2) {
                // yapilacak bir sey yok
            }
            return false;
        }
    }

    private void startVibration(AudioAttributes aa) {
        try {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) {
                return;
            }
            long[] pattern = {0, 800, 500, 800, 500, 800, 500};
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0), aa);
            } else {
                vibrator.vibrate(pattern, 0);
            }
        } catch (Exception e) {
            // yapilacak bir sey yok
        }
    }

    private void stopSound() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception e) {
                // yapilacak bir sey yok
            }
            try {
                player.release();
            } catch (Exception e) {
                // yapilacak bir sey yok
            }
            player = null;
        }
        if (vibrator != null) {
            try {
                vibrator.cancel();
            } catch (Exception e) {
                // yapilacak bir sey yok
            }
        }
    }

    /** Alarm ses seviyesini en az %90'a yukseltir; sonunda eski haline getirir. */
    private void raiseVolume() {
        try {
            audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            int max = audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            int cur = audio.getStreamVolume(AudioManager.STREAM_ALARM);
            if (oldVolume < 0) {
                oldVolume = cur;
            }
            int target = (int) Math.round(max * 0.9);
            if (cur < target) {
                audio.setStreamVolume(AudioManager.STREAM_ALARM, target, 0);
            }
        } catch (Exception e) {
            // yapilacak bir sey yok
        }
    }

    private void restoreVolume() {
        if (oldVolume >= 0 && audio != null) {
            try {
                audio.setStreamVolume(AudioManager.STREAM_ALARM, oldVolume, 0);
            } catch (Exception e) {
                // yapilacak bir sey yok
            }
        }
        oldVolume = -1;
    }

    private void shutdown(boolean removeNotification) {
        handler.removeCallbacks(stopRunnable);
        stopSound();
        restoreVolume();
        running = false;
        stopForeground(removeNotification);
        stopSelf();
    }
}
