package com.gocbil.hatirlatici;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Bildirimdeki "Gocbil'i Ac" dugmesi icin gorunmez ara ekran:
 * calan alarm sesini susturur, Gocbil'i (yoksa magaza aramasini) acar ve kapanir.
 */
public class OpenGocbilActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int step = getIntent().getIntExtra(Scheduler.EXTRA_STEP, -1);

        AlarmService.stop(this, false);

        boolean found = Scheduler.gocbilInstalled(this);
        Intent in = Scheduler.gocbilIntent(this);
        try {
            startActivity(in);
            if (!found) {
                Toast.makeText(Lang.wrap(this), R.string.gocbil_not_found,
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(Lang.wrap(this), R.string.gocbil_open_error,
                    Toast.LENGTH_LONG).show();
        }

        // Bildirimdeki Evet/Hayir dugmeleri kaybolmasin: soru bildirimini sessizce geri koy
        if (step >= 2 && step < Scheduler.STEP_COUNT) {
            Scheduler.showNotification(this, step, false);
        }
        finish();
    }
}
