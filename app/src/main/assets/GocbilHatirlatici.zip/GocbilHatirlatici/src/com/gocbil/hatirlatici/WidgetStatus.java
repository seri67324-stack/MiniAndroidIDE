package com.gocbil.hatirlatici;

public class WidgetStatus extends WidgetBase {
    @Override
    protected int kind() {
        return K_STATUS;
    }
}
