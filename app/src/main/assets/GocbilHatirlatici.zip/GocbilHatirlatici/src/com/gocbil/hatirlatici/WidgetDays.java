package com.gocbil.hatirlatici;

public class WidgetDays extends WidgetBase {
    @Override
    protected int kind() {
        return K_DAYS;
    }
}
