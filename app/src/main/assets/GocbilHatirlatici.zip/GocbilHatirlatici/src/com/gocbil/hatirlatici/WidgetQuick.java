package com.gocbil.hatirlatici;

public class WidgetQuick extends WidgetBase {
    @Override
    protected int kind() {
        return K_QUICK;
    }
}
