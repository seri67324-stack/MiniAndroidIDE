package com.gocbil.hatirlatici;

public class WidgetProgress extends WidgetBase {
    @Override
    protected int kind() {
        return K_PROGRESS;
    }
}
