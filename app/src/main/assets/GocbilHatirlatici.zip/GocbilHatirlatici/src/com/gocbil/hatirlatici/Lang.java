package com.gocbil.hatirlatici;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;

import java.util.Locale;

/**
 * Uygulama ici dil secimi (tr / ar). Kayitli dil yoksa telefon dili Arapcaysa ar, degilse tr.
 * wrap() verilen context'i secili dile gore ayarlar; bildirim ve widget metinleri de buna uyar.
 */
public class Lang {

    public static final String KEY = "lang";
    public static final String TR = "tr";
    public static final String AR = "ar";

    public static String get(Context c) {
        String v = c.getSharedPreferences(Scheduler.PREFS, Context.MODE_PRIVATE)
                .getString(KEY, "");
        if (AR.equals(v) || TR.equals(v)) {
            return v;
        }
        String sys = "";
        try {
            sys = Resources.getSystem().getConfiguration().locale.getLanguage();
        } catch (Exception e) {
            // varsayilan tr
        }
        return AR.equals(sys) ? AR : TR;
    }

    public static void set(Context c, String lang) {
        c.getSharedPreferences(Scheduler.PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, lang).commit();
    }

    public static boolean isRtl(Context c) {
        return AR.equals(get(c));
    }

    public static Context wrap(Context base) {
        try {
            Locale l = new Locale(get(base));
            Configuration cfg = new Configuration(base.getResources().getConfiguration());
            if (Build.VERSION.SDK_INT >= 17) {
                cfg.setLocale(l);
                cfg.setLayoutDirection(l);
                return base.createConfigurationContext(cfg);
            }
        } catch (Exception e) {
            // dil uygulanamazsa varsayilan context ile devam
        }
        return base;
    }
}
