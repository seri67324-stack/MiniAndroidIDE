package com.gocbil.hatirlatici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent.getAction();
        if (a == null) {
            return;
        }
        if (Intent.ACTION_BOOT_COMPLETED.equals(a)
                || "android.intent.action.QUICKBOOT_POWERON".equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a)
                || Intent.ACTION_TIME_CHANGED.equals(a)) {
            // Tarih yoksa scheduleAll sadece widget yenileme alarmini kurar
            Scheduler.scheduleAll(context);
            Scheduler.prefs(context).edit()
                    .putLong(Scheduler.KEY_REARM, System.currentTimeMillis())
                    .commit();
        }
    }
}
