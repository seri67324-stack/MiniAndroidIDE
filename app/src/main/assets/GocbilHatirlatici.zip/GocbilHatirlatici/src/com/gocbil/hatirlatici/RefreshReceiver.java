package com.gocbil.hatirlatici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Gece yarisindan sonra widget'lari tazeler ve bir sonraki gece icin yeniden kurulur. */
public class RefreshReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Scheduler.scheduleRefresh(context);
        WidgetBase.updateAll(context);
    }
}
