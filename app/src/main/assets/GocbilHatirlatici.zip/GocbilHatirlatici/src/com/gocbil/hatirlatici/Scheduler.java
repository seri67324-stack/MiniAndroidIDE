package com.gocbil.hatirlatici;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Ortak yardimci sinif: tarih hesaplari, alarm kurma/iptal, bildirim olusturma.
 * Ses ve titresimi AlarmService calar (alarm kanalindan, sessiz modda da duyulur).
 */
public class Scheduler {

    public static final String PREFS = "gocbil_prefs";
    public static final String KEY_LAST = "last_verify";
    public static final String KEY_STEP = "current_step";
    public static final String KEY_STEP_STATE = "step_state";
    public static final String KEY_HIST = "history";
    public static final String KEY_PREV_LAST = "prev_last";
    public static final String KEY_PREV_HIST = "prev_hist";
    public static final String KEY_GUIDE = "guide_done";
    public static final String KEY_FIRED = "last_fired";
    public static final String KEY_FIRED_STEP = "last_fired_step";
    public static final String KEY_REARM = "last_rearm";
    public static final String KEY_GOCBIL_PKG = "gocbil_pkg";
    // Saat gruplari: 0 on hatirlatma, 1 sabah, 2 aksam, 3 gece
    public static final String[] KEY_TIME = {"t_pre", "t_morning", "t_evening", "t_night"};

    public static final String CHANNEL_ID = "gocbil_hatirlatma_v3";
    private static final String OLD_CHANNEL_1 = "gocbil_hatirlatmalari";
    private static final String OLD_CHANNEL_2 = "gocbil_alarm_v2";

    public static final String ACTION_YES = "com.gocbil.hatirlatici.ACTION_YES";
    public static final String ACTION_NO = "com.gocbil.hatirlatici.ACTION_NO";
    public static final String EXTRA_STEP = "step";
    public static final String EXTRA_TEST = "test";

    public static final int PERIOD_DAYS = 28;
    public static final int STEP_COUNT = 7;
    public static final int LAST_STEP = 6;
    public static final int NOTIF_BASE = 1000;
    public static final int FG_ID = 900;
    public static final int TEST_NOTIF_ID = 999;

    // Adimlar (dogrulama gunu = 1. gun = offset 0):
    // 0: 2 gun once 10:00      1: 1 gun once 10:00
    // 2: 1. gun 09:00          3: 1. gun 18:00
    // 4: 2. gun 09:00          5: 2. gun 18:00 (SON UYARI)
    // 6: 2. gun 21:00 (SON UYARI)
    private static final int[] DAY_OFFSET = {-2, -1, 0, 0, 1, 1, 1};
    // Her adimin hangi saat grubuna bagli oldugu
    private static final int[] STEP_GROUP = {0, 0, 1, 2, 1, 2, 3};
    // Varsayilan saatler (dakika): 10:00, 09:00, 18:00, 21:00
    private static final int[] DEFAULT_MIN = {600, 540, 1080, 1260};
    private static final int MAX_HIST = 24;

    private static final long DAY_MS = 24L * 60L * 60L * 1000L;

    // ---------- Tarih / veri ----------

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static long startOfDay(long t) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static long today() {
        return startOfDay(System.currentTimeMillis());
    }

    public static long addDays(long t, int days) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTimeInMillis();
    }

    public static int daysBetween(long from, long to) {
        return (int) Math.round((to - from) / (double) DAY_MS);
    }

    public static long getLast(Context c) {
        return prefs(c).getLong(KEY_LAST, 0L);
    }

    // ---------- Gecmis ----------

    /** Gecmis tarihleri eskiden yeniye dondurur. */
    public static ArrayList<Long> getHistory(Context c) {
        ArrayList<Long> out = new ArrayList<Long>();
        String s = prefs(c).getString(KEY_HIST, "");
        if (s.length() > 0) {
            String[] p = s.split(",");
            for (int i = 0; i < p.length; i++) {
                try {
                    out.add(Long.valueOf(p[i].trim()));
                } catch (NumberFormatException e) {
                    // bozuk kaydi atla
                }
            }
        }
        if (out.isEmpty()) {
            long l = getLast(c);
            if (l != 0L) {
                out.add(Long.valueOf(l));
            }
        }
        Collections.sort(out);
        return out;
    }

    private static String join(ArrayList<Long> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(list.get(i).longValue());
        }
        return sb.toString();
    }

    /**
     * Yeni dogrulama tarihini kaydeder. Onceki durum geri alma icin saklanir.
     * Secilen tarih eski son tarihten once ise bu bir duzeltme sayilir:
     * eski (yanlis) kayit gecmisten silinir.
     */
    public static void recordDate(Context c, long t) {
        SharedPreferences p = prefs(c);
        long old = p.getLong(KEY_LAST, 0L);
        ArrayList<Long> h = getHistory(c);
        SharedPreferences.Editor e = p.edit();
        if (t != old) {
            e.putLong(KEY_PREV_LAST, old);
            e.putString(KEY_PREV_HIST, join(h));
            if (old != 0L && t < old) {
                h.remove(Long.valueOf(old));
            }
            if (!h.contains(Long.valueOf(t))) {
                h.add(Long.valueOf(t));
            }
            Collections.sort(h);
            while (h.size() > MAX_HIST) {
                h.remove(0);
            }
            e.putString(KEY_HIST, join(h));
        }
        e.putLong(KEY_LAST, t);
        e.putInt(KEY_STEP, -1);
        e.putString(KEY_STEP_STATE, "bekliyor");
        e.commit();
    }

    public static boolean canUndo(Context c) {
        return prefs(c).getLong(KEY_PREV_LAST, 0L) != 0L;
    }

    public static long getUndoDate(Context c) {
        return prefs(c).getLong(KEY_PREV_LAST, 0L);
    }

    /** Son islemi geri alir: onceki tarihe ve onceki gecmise doner. */
    public static boolean undo(Context ctx) {
        SharedPreferences p = prefs(ctx);
        long prev = p.getLong(KEY_PREV_LAST, 0L);
        if (prev == 0L) {
            return false;
        }
        AlarmService.stop(ctx, true);
        cancelNotifications(ctx);
        cancelAlarms(ctx);
        String ph = p.getString(KEY_PREV_HIST, "");
        p.edit()
                .putLong(KEY_LAST, prev)
                .putString(KEY_HIST, ph)
                .putLong(KEY_PREV_LAST, 0L)
                .putString(KEY_PREV_HIST, "")
                .putInt(KEY_STEP, -1)
                .putString(KEY_STEP_STATE, "bekliyor")
                .commit();
        scheduleAll(ctx);
        return true;
    }

    /** Gecmisten bir kaydi siler. En az bir kayit kalmali; yoksa false doner. */
    public static boolean deleteHistory(Context ctx, long t) {
        ArrayList<Long> h = getHistory(ctx);
        if (h.size() <= 1) {
            return false;
        }
        h.remove(Long.valueOf(t));
        SharedPreferences.Editor e = prefs(ctx).edit();
        e.putString(KEY_HIST, join(h));
        boolean relast = (t == getLast(ctx));
        if (relast) {
            e.putLong(KEY_LAST, h.get(h.size() - 1).longValue());
            e.putLong(KEY_PREV_LAST, 0L);
            e.putString(KEY_PREV_HIST, "");
            e.putInt(KEY_STEP, -1);
            e.putString(KEY_STEP_STATE, "bekliyor");
        }
        e.commit();
        if (relast) {
            AlarmService.stop(ctx, true);
            cancelNotifications(ctx);
            cancelAlarms(ctx);
            scheduleAll(ctx);
        }
        return true;
    }

    // ---------- Ayarlanabilir saatler ----------

    public static int getTimeMin(Context c, int group) {
        return prefs(c).getInt(KEY_TIME[group], DEFAULT_MIN[group]);
    }

    public static void setTimeMin(Context c, int group, int min) {
        prefs(c).edit().putInt(KEY_TIME[group], min).commit();
    }

    public static int stepMinutes(Context c, int step) {
        return getTimeMin(c, STEP_GROUP[step]);
    }

    public static String formatTime(int min) {
        return String.format(Locale.US, "%02d:%02d", min / 60, min % 60);
    }

    /** Ayni gun icinde sabah < aksam < gece olmali. */
    public static boolean timesValid(int morning, int evening, int night) {
        return morning < evening && evening < night;
    }

    public static long getNext(Context c) {
        long last = getLast(c);
        if (last == 0L) {
            return 0L;
        }
        return addDays(last, PERIOD_DAYS);
    }

    public static String format(long t) {
        return new SimpleDateFormat("dd.MM.yyyy", Locale.US).format(new Date(t));
    }

    public static String formatShort(long t) {
        return new SimpleDateFormat("dd.MM  HH:mm", Locale.US).format(new Date(t));
    }

    public static long stepTime(Context ctx, long next, int step) {
        int min = stepMinutes(ctx, step);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(next);
        c.add(Calendar.DAY_OF_YEAR, DAY_OFFSET[step]);
        c.set(Calendar.HOUR_OF_DAY, min / 60);
        c.set(Calendar.MINUTE, min % 60);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    /** Alarm sesinin kac ms calacagi. */
    public static int alertDuration(int step) {
        if (step == 0 || step == 1) {
            return 15000;
        }
        if (step == 5 || step == 6) {
            return 90000;
        }
        return 45000;
    }

    // ---------- Alarmlar ----------

    public static int immutableFlag() {
        if (Build.VERSION.SDK_INT >= 23) {
            return 0x04000000; // PendingIntent.FLAG_IMMUTABLE
        }
        return 0;
    }

    private static PendingIntent alarmPi(Context ctx, int step) {
        Intent i = new Intent(ctx, AlarmReceiver.class);
        i.putExtra(EXTRA_STEP, step);
        return PendingIntent.getBroadcast(ctx, 100 + step, i,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
    }

    public static boolean canScheduleExact(Context ctx) {
        if (Build.VERSION.SDK_INT < 31) {
            return true;
        }
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            Object r = am.getClass().getMethod("canScheduleExactAlarms").invoke(am);
            return (r instanceof Boolean) && ((Boolean) r).booleanValue();
        } catch (Exception e) {
            return true;
        }
    }

    private static void setAlarm(Context ctx, AlarmManager am, long t, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                if (canScheduleExact(ctx)) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                }
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, t, pi);
            }
        } catch (SecurityException e) {
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
                } else {
                    am.set(AlarmManager.RTC_WAKEUP, t, pi);
                }
            } catch (Exception e2) {
                // yapilacak bir sey yok
            }
        }
    }

    public static void cancelAlarms(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        for (int s = 0; s < STEP_COUNT; s++) {
            PendingIntent pi = alarmPi(ctx, s);
            am.cancel(pi);
            pi.cancel();
        }
    }

    public static void cancelNotifications(Context ctx) {
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(FG_ID);
        nm.cancel(TEST_NOTIF_ID);
        for (int s = 0; s < STEP_COUNT; s++) {
            nm.cancel(NOTIF_BASE + s);
        }
    }

    /** Eski alarmlari siler, gelecekteki adimlari yeniden kurar. */
    public static void scheduleAll(Context ctx) {
        cancelAlarms(ctx);
        scheduleRefresh(ctx);
        long next = getNext(ctx);
        if (next == 0L) {
            WidgetBase.updateAll(ctx);
            return;
        }
        long now = System.currentTimeMillis();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        for (int s = 0; s < STEP_COUNT; s++) {
            long t = stepTime(ctx, next, s);
            if (t > now) {
                setAlarm(ctx, am, t, alarmPi(ctx, s));
            }
        }
        WidgetBase.updateAll(ctx);
    }

    /** Her gece yarisindan sonra widget'lari tazelemek icin esnek alarm kurar. */
    public static void scheduleRefresh(Context ctx) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(ctx, RefreshReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 200, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
            long t = addDays(today(), 1) + 60000L;
            am.set(AlarmManager.RTC, t, pi);
        } catch (Exception e) {
            // yapilacak bir sey yok
        }
    }

    /** "Yaptim": sesi sustur, bugunu son dogrulama yap, her seyi iptal et, yeniden kur. */
    public static long markDone(Context ctx) {
        AlarmService.stop(ctx, true);
        cancelNotifications(ctx);
        cancelAlarms(ctx);
        recordDate(ctx, today());
        scheduleAll(ctx);
        return getNext(ctx);
    }

    // ---------- Sistem kontrolu ----------

    public static boolean notificationsEnabled(Context ctx) {
        try {
            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 24 && !nm.areNotificationsEnabled()) {
                return false;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = nm.getNotificationChannel(CHANNEL_ID);
                if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) {
                    return false;
                }
            }
        } catch (Exception e) {
            // bilinmiyorsa sorun yok kabul et
        }
        return true;
    }

    public static boolean batteryUnrestricted(Context ctx) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        try {
            PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(ctx.getPackageName());
        } catch (Exception e) {
            return true;
        }
    }

    // ---------- Ilk acilis rehberi ----------

    /** Rehber daha once bitirildi mi? Tarihi zaten kayitli eski kullanicilar icin bitmis sayilir. */
    public static boolean guideDone(Context c) {
        SharedPreferences p = prefs(c);
        if (p.contains(KEY_GUIDE)) {
            return p.getBoolean(KEY_GUIDE, false);
        }
        return getLast(c) != 0L;
    }

    public static void setGuideDone(Context c, boolean done) {
        prefs(c).edit().putBoolean(KEY_GUIDE, done).commit();
    }

    // ---------- Alarm tani bilgileri ----------

    /** Bu adimin alarmi sistemde gercekten kurulu mu? */
    public static boolean alarmPending(Context ctx, int step) {
        Intent i = new Intent(ctx, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 100 + step, i,
                PendingIntent.FLAG_NO_CREATE | immutableFlag());
        return pi != null;
    }

    /** Simdiden sonraki ilk adimin numarasi; yoksa -1. */
    public static int nextStepIndex(Context ctx) {
        long next = getNext(ctx);
        if (next == 0L) {
            return -1;
        }
        long now = System.currentTimeMillis();
        for (int s = 0; s < STEP_COUNT; s++) {
            if (stepTime(ctx, next, s) > now) {
                return s;
            }
        }
        return -1;
    }

    public static long getLastFired(Context c) {
        return prefs(c).getLong(KEY_FIRED, 0L);
    }

    public static int getLastFiredStep(Context c) {
        return prefs(c).getInt(KEY_FIRED_STEP, -1);
    }

    public static long getLastRearm(Context c) {
        return prefs(c).getLong(KEY_REARM, 0L);
    }

    // ---------- Gocbil'i acma ----------

    private static String normalizeName(String in) {
        String s = in.toLowerCase(Locale.ENGLISH);
        s = s.replace("\u0307", "");
        s = s.replace('\u00f6', 'o').replace('\u00e7', 'c').replace('\u0131', 'i')
                .replace('\u015f', 's').replace('\u011f', 'g').replace('\u00fc', 'u');
        s = s.replace(" ", "");
        return s;
    }

    /** Yuklu uygulamalar arasinda adi "Gocbil" olani bulur (kendi uygulamamizi atlar). */
    private static String findGocbilPackage(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            for (int i = 0; i < apps.size(); i++) {
                ApplicationInfo a = apps.get(i);
                if (a.packageName.equals(ctx.getPackageName())) {
                    continue;
                }
                if (pm.getLaunchIntentForPackage(a.packageName) == null) {
                    continue;
                }
                CharSequence label = pm.getApplicationLabel(a);
                String name = (label == null) ? "" : normalizeName(label.toString());
                if (name.equals("gocbil")
                        || a.packageName.toLowerCase(Locale.ENGLISH).contains("gocbil")) {
                    return a.packageName;
                }
            }
        } catch (Exception e) {
            // bulunamadi
        }
        return null;
    }

    /** Gocbil'in acilis intent'i; yuklu degilse null. */
    private static Intent gocbilLaunchIntent(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        SharedPreferences p = prefs(ctx);
        String pkg = p.getString(KEY_GOCBIL_PKG, "");
        Intent in = null;
        if (pkg.length() > 0) {
            in = pm.getLaunchIntentForPackage(pkg);
        }
        if (in == null) {
            pkg = findGocbilPackage(ctx);
            if (pkg != null) {
                p.edit().putString(KEY_GOCBIL_PKG, pkg).commit();
                in = pm.getLaunchIntentForPackage(pkg);
            }
        }
        return in;
    }

    public static boolean gocbilInstalled(Context ctx) {
        return gocbilLaunchIntent(ctx) != null;
    }

    /** Gocbil'i acar; yuklu degilse Play Store'da "Gocbil" aramasini acar. */
    public static Intent gocbilIntent(Context ctx) {
        Intent in = gocbilLaunchIntent(ctx);
        if (in == null) {
            in = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=G%C3%B6%C3%A7Bil&c=apps"));
            if (in.resolveActivity(ctx.getPackageManager()) == null) {
                in = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/search?q=G%C3%B6%C3%A7Bil&c=apps"));
            }
        }
        in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return in;
    }

    // ---------- Bildirim + ses ----------

    public static Uri soundUri() {
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) {
            u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        return u;
    }

    /**
     * Kanalin kendisi sessiz: ses ve titresimi AlarmService alarm kanalindan calar.
     * Boylece telefon sessizde olsa bile duyulur, cift ses de olmaz.
     */
    public static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        ctx = Lang.wrap(ctx);
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(OLD_CHANNEL_1) != null) {
            nm.deleteNotificationChannel(OLD_CHANNEL_1);
        }
        if (nm.getNotificationChannel(OLD_CHANNEL_2) != null) {
            nm.deleteNotificationChannel(OLD_CHANNEL_2);
        }
        if (nm.getNotificationChannel(CHANNEL_ID) != null) {
            return;
        }
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID,
                ctx.getString(R.string.channel_name), NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription(ctx.getString(R.string.channel_desc));
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.enableLights(true);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    private static PendingIntent actionPi(Context ctx, String action, int step,
                                          boolean test, int code) {
        Intent i = new Intent(ctx, ActionReceiver.class);
        i.setAction(action);
        i.putExtra(EXTRA_STEP, step);
        i.putExtra(EXTRA_TEST, test);
        return PendingIntent.getBroadcast(ctx, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
    }

    public static Notification buildNotification(Context ctx, int step, boolean test) {
        ctx = Lang.wrap(ctx);
        ensureChannel(ctx);

        String text;
        boolean buttons = true;
        boolean urgent = false;

        switch (step) {
            case 0:
                text = ctx.getString(R.string.notif_pre2);
                buttons = false;
                break;
            case 1:
                text = ctx.getString(R.string.notif_pre1);
                buttons = false;
                break;
            case 5:
            case 6:
                text = ctx.getString(R.string.notif_last_warning);
                urgent = true;
                break;
            default:
                text = ctx.getString(R.string.notif_question);
                break;
        }

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(ctx, CHANNEL_ID);
        } else {
            b = new Notification.Builder(ctx);
        }

        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(ctx, 3000 + step, open,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());

        b.setSmallIcon(android.R.drawable.ic_popup_reminder);
        b.setContentTitle(ctx.getString(R.string.notif_title));
        b.setContentText(text);
        b.setStyle(new Notification.BigTextStyle().bigText(text));
        b.setAutoCancel(true);
        b.setContentIntent(openPi);
        b.setWhen(System.currentTimeMillis());
        b.setColor(0xFF0D2B5E);

        if (urgent) {
            b.setCategory(Notification.CATEGORY_ALARM);
        } else {
            b.setCategory(Notification.CATEGORY_REMINDER);
        }

        if (Build.VERSION.SDK_INT < 26) {
            if (urgent) {
                b.setPriority(Notification.PRIORITY_MAX);
            } else {
                b.setPriority(Notification.PRIORITY_HIGH);
            }
        }

        if (buttons) {
            int base = test ? 5000 : 2000 + step * 10;
            b.addAction(0, ctx.getString(R.string.action_yes),
                    actionPi(ctx, ACTION_YES, step, test, base));
            b.addAction(0, ctx.getString(R.string.action_no),
                    actionPi(ctx, ACTION_NO, step, test, base + 1));
        }

        // Gocbil'i dogrudan acan dugme (gorunmez ara ekran uzerinden)
        Intent oi = new Intent(ctx, OpenGocbilActivity.class);
        oi.putExtra(EXTRA_STEP, test ? -1 : step);
        oi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY);
        PendingIntent gPi = PendingIntent.getActivity(ctx, 3100 + step, oi,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
        b.addAction(0, ctx.getString(R.string.action_open_gocbil), gPi);
        return b.build();
    }

    /** Servis baslatilamazsa yedek: bildirimi dogrudan goster. */
    public static void showNotification(Context ctx, int step, boolean test) {
        NotificationManager nm =
                (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        try {
            nm.notify(FG_ID, buildNotification(ctx, step, test));
        } catch (Exception e) {
            // bildirim izni yoksa sessizce gec
        }
    }

    /** Yedek ses: alarm kanalindan zil sesi. */
    public static void playFallbackSound(Context ctx) {
        try {
            Ringtone r = RingtoneManager.getRingtone(ctx, soundUri());
            if (r != null) {
                if (Build.VERSION.SDK_INT >= 21) {
                    r.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build());
                }
                r.play();
            }
        } catch (Exception e) {
            // yapilacak bir sey yok
        }
    }

    /** Bildirim + yuksek sesli alarm baslatir (AlarmService). */
    public static void startAlert(Context ctx, int step, boolean test) {
        try {
            Intent i = new Intent(ctx, AlarmService.class);
            i.putExtra(EXTRA_STEP, step);
            i.putExtra(EXTRA_TEST, test);
            if (Build.VERSION.SDK_INT >= 26) {
                ctx.startForegroundService(i);
            } else {
                ctx.startService(i);
            }
        } catch (Exception e) {
            showNotification(ctx, step, test);
            playFallbackSound(ctx);
        }
    }
}
