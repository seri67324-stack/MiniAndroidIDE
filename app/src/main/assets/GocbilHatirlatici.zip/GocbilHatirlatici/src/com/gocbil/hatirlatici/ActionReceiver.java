package com.gocbil.hatirlatici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class ActionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            return;
        }
        final Context lc = Lang.wrap(context);
        boolean test = intent.getBooleanExtra(Scheduler.EXTRA_TEST, false);
        int step = intent.getIntExtra(Scheduler.EXTRA_STEP, -1);

        // Once sesi sustur ve bildirimi kaldir
        AlarmService.stop(context, true);
        Scheduler.cancelNotifications(context);

        if (test) {
            Toast.makeText(lc, R.string.test_answer, Toast.LENGTH_LONG).show();
            return;
        }

        if (Scheduler.ACTION_YES.equals(action)) {
            long next = Scheduler.markDone(context);
            String msg = lc.getString(R.string.great_msg, Scheduler.format(next));
            Toast.makeText(lc, msg, Toast.LENGTH_LONG).show();
        } else if (Scheduler.ACTION_NO.equals(action)) {
            Scheduler.prefs(context).edit()
                    .putInt(Scheduler.KEY_STEP, step)
                    .putString(Scheduler.KEY_STEP_STATE, "hayir")
                    .commit();
            if (step == Scheduler.LAST_STEP) {
                Toast.makeText(lc, R.string.reminder_last_toast, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(lc, R.string.reminder_no_toast, Toast.LENGTH_LONG).show();
            }
        }
    }
}
