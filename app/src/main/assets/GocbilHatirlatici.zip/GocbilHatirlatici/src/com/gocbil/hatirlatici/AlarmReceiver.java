package com.gocbil.hatirlatici;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        int step = intent.getIntExtra(Scheduler.EXTRA_STEP, -1);
        if (step < 0 || step >= Scheduler.STEP_COUNT) {
            return;
        }
        if (Scheduler.getLast(context) == 0L) {
            return;
        }
        Scheduler.prefs(context).edit()
                .putInt(Scheduler.KEY_STEP, step)
                .putString(Scheduler.KEY_STEP_STATE, "soruldu")
                .putLong(Scheduler.KEY_FIRED, System.currentTimeMillis())
                .putInt(Scheduler.KEY_FIRED_STEP, step)
                .commit();
        Scheduler.startAlert(context, step, false);
        WidgetBase.updateAll(context);
    }
}
