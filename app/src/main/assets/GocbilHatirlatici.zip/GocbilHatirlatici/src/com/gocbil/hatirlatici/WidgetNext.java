package com.gocbil.hatirlatici;

public class WidgetNext extends WidgetBase {
    @Override
    protected int kind() {
        return K_NEXT;
    }
}
