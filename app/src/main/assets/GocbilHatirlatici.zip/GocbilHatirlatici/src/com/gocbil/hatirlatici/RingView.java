package com.gocbil.hatirlatici;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/** Ilerleme halkasi: ortada buyuk gun sayisi, altinda kucuk aciklama. */
public class RingView extends View {

    private Paint trackPaint;
    private Paint arcPaint;
    private Paint bigPaint;
    private Paint smallPaint;
    private RectF rect;

    private float fraction = 0f;
    private int color = 0xFF2E7D32;
    private String big = "";
    private String small = "";

    public RingView(Context context) {
        super(context);
        init();
    }

    public RingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public RingView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        rect = new RectF();

        trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setColor(0xFFE6EBF3);

        arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);

        bigPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bigPaint.setTypeface(Typeface.DEFAULT_BOLD);
        bigPaint.setTextAlign(Paint.Align.CENTER);
        bigPaint.setColor(0xFF14213D);

        smallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        smallPaint.setTextAlign(Paint.Align.CENTER);
        smallPaint.setColor(0xFF6B7A90);
    }

    public void setData(float fraction, int color, String big, String small) {
        if (fraction < 0f) {
            fraction = 0f;
        }
        if (fraction > 1f) {
            fraction = 1f;
        }
        this.fraction = fraction;
        this.color = color;
        this.big = big;
        this.small = small;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float density = getResources().getDisplayMetrics().density;
        float stroke = 14f * density;
        float w = getWidth();
        float h = getHeight();
        float size = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;
        float r = size / 2f - stroke;

        trackPaint.setStrokeWidth(stroke);
        arcPaint.setStrokeWidth(stroke);
        arcPaint.setColor(color);

        rect.set(cx - r, cy - r, cx + r, cy + r);
        canvas.drawCircle(cx, cy, r, trackPaint);
        if (fraction > 0.005f) {
            canvas.drawArc(rect, -90f, 360f * fraction, false, arcPaint);
        }

        // Buyuk yazi (sigana kadar kucult)
        float bigSize = r * 0.95f;
        float maxWidth = r * 1.45f;
        bigPaint.setTextSize(bigSize);
        while (bigPaint.measureText(big) > maxWidth && bigSize > 12f * density) {
            bigSize -= 2f * density;
            bigPaint.setTextSize(bigSize);
        }
        Paint.FontMetrics fm = bigPaint.getFontMetrics();
        float bigY = cy - (fm.ascent + fm.descent) / 2f - r * 0.10f;
        canvas.drawText(big, cx, bigY, bigPaint);

        smallPaint.setTextSize(r * 0.20f);
        canvas.drawText(small, cx, cy + r * 0.52f, smallPaint);
    }
}
